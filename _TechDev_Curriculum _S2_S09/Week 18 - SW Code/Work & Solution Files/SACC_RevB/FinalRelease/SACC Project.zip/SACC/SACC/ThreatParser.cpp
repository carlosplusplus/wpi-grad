#include "ThreatParser.h"



ThreatParser::ThreatParser(void)
{
}

ThreatParser::~ThreatParser(void)
{
}
