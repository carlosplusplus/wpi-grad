%% Carlos Lazo
%  ELDP Class of 2011
%  Introduction to MATLAB Assignment
%  Due: 9/15/08 @ 8:30am

function v = alternate(n)

% Alternate the [1 0] string 2*n times in a vector.

v = repmat([1,0],1,n);