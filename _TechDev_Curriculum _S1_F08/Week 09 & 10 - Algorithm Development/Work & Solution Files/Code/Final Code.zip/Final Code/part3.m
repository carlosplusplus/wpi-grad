function clean = part2(data,corruption_level)


end
