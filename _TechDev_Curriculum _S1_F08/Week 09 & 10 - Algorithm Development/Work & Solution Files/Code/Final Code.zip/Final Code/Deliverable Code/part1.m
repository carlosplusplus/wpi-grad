function clean = part1(input)
    b = filterFinal;
    clean = filter(b.Numerator,1,input);
end